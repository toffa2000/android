package com.example.antonello.myapplication;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Context context = getApplicationContext();
        CharSequence text;
        int duration = Toast.LENGTH_SHORT;
        Toast toast;
        switch (item.getItemId()) {
            case R.id.first:
                text = ""+R.string.first_toast;
                toast = Toast.makeText(context, text, duration);
                toast.show();
                return true;
            case R.id.second:
                text = ""+R.string.second_toast;
                toast = Toast.makeText(context, text, duration);
                toast.show();
                return true;
            case R.id.third:
                text = ""+R.string.third_toast;
                toast = Toast.makeText(context, text, duration);
                toast.show();
                return true;
            case R.id.fourth:
                text = ""+R.string.fourth_toast;
                toast = Toast.makeText(context, text, duration);
                toast.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }


    }
}
